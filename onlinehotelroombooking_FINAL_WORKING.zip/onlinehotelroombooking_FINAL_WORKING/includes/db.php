<?php
require_once __DIR__ . '/config.php';

$host = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'hoteleasy';

mysqli_report(MYSQLI_REPORT_OFF);
$conn = new mysqli($host, $dbUser, $dbPass);
if ($conn->connect_errno) {
    die('<div style="font-family:Arial;padding:30px"><h2>MySQL is not running</h2><p>Open XAMPP and start <b>MySQL</b>, then refresh this page.</p><p>If MySQL uses a password for root, edit <b>includes/db.php</b> and set <b>$dbPass</b>.</p></div>');
}
$conn->set_charset('utf8mb4');

if (!$conn->query("CREATE DATABASE IF NOT EXISTS `$dbName` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")) {
    die('<div style="font-family:Arial;padding:30px"><h2>Database creation failed</h2><p>' . e($conn->error) . '</p></div>');
}
if (!$conn->select_db($dbName)) {
    die('<div style="font-family:Arial;padding:30px"><h2>Database selection failed</h2><p>' . e($conn->error) . '</p></div>');
}

/* Create the complete schema. Existing older tables are upgraded below. */
$schema = [
"CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(30) DEFAULT '',
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    capacity INT NOT NULL DEFAULT 2,
    quantity INT NOT NULL DEFAULT 1,
    price DECIMAL(10,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    room_id INT NOT NULL,
    checkin DATE NOT NULL,
    checkout DATE NOT NULL,
    guests INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status ENUM('Confirmed','Cancelled') NOT NULL DEFAULT 'Confirmed',
    payment_status ENUM('Paid','Pending','Refunded') NOT NULL DEFAULT 'Pending',
    payment_ref VARCHAR(80) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(room_id), INDEX(user_id)
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    room_id INT NOT NULL,
    rating INT NOT NULL,
    review TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB",
"CREATE TABLE IF NOT EXISTS static_pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page_key VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(150) NOT NULL,
    content TEXT NOT NULL
) ENGINE=InnoDB"
];
foreach ($schema as $sql) {
    if (!$conn->query($sql)) {
        die('<div style="font-family:Arial;padding:30px"><h2>Database setup failed</h2><p>' . e($conn->error) . '</p></div>');
    }
}

/* Upgrade databases created by an earlier version of the project. */
function ensure_column($conn, $table, $column, $definition) {
    $safeTable = $conn->real_escape_string($table);
    $safeColumn = $conn->real_escape_string($column);
    $check = $conn->query("SHOW COLUMNS FROM `$safeTable` LIKE '$safeColumn'");
    if ($check && $check->num_rows === 0) {
        if (!$conn->query("ALTER TABLE `$safeTable` ADD COLUMN `$safeColumn` $definition")) {
            die('<div style="font-family:Arial;padding:30px"><h2>Database upgrade failed</h2><p>' . e($conn->error) . '</p></div>');
        }
    }
}
ensure_column($conn, 'users', 'phone', "VARCHAR(30) DEFAULT ''");
ensure_column($conn, 'users', 'created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
ensure_column($conn, 'rooms', 'description', "TEXT NOT NULL DEFAULT ''");
ensure_column($conn, 'rooms', 'capacity', 'INT NOT NULL DEFAULT 2');
ensure_column($conn, 'rooms', 'quantity', 'INT NOT NULL DEFAULT 1');
ensure_column($conn, 'rooms', 'price', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
ensure_column($conn, 'bookings', 'guests', 'INT NOT NULL DEFAULT 1');
ensure_column($conn, 'bookings', 'total', 'DECIMAL(10,2) NOT NULL DEFAULT 0');
ensure_column($conn, 'bookings', 'status', "ENUM('Confirmed','Cancelled') NOT NULL DEFAULT 'Confirmed'");
ensure_column($conn, 'bookings', 'payment_status', "ENUM('Paid','Pending','Refunded') NOT NULL DEFAULT 'Pending'");
ensure_column($conn, 'bookings', 'payment_ref', "VARCHAR(80) DEFAULT ''");
ensure_column($conn, 'bookings', 'created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
ensure_column($conn, 'reviews', 'rating', 'INT NOT NULL DEFAULT 5');
ensure_column($conn, 'reviews', 'review', "TEXT NOT NULL DEFAULT ''");
ensure_column($conn, 'reviews', 'created_at', 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP');
ensure_column($conn, 'static_pages', 'content', "TEXT NOT NULL DEFAULT ''");

/* Add indexes/foreign keys only where practical; booking logic itself enforces ownership. */

$roomCountResult = $conn->query("SELECT COUNT(*) AS c FROM rooms");
$roomCount = $roomCountResult ? (int)$roomCountResult->fetch_assoc()['c'] : 0;
if ($roomCount === 0) {
    $seed = [
        ['Standard Room','Comfortable room for solo travellers and couples. Includes Wi-Fi, breakfast and housekeeping.',2,10,2500],
        ['Deluxe Room','Spacious room with upgraded interiors, breakfast, Wi-Fi and city views.',3,8,3500],
        ['Executive Room','Premium business-friendly room with work desk, lounge access and breakfast.',3,6,4800],
        ['Suite Room','Large suite with separate living space, premium amenities and complimentary breakfast.',4,4,7000]
    ];
    $stmt = $conn->prepare("INSERT INTO rooms(room_type,description,capacity,quantity,price) VALUES(?,?,?,?,?)");
    foreach ($seed as $r) {
        $stmt->bind_param('ssiid', $r[0], $r[1], $r[2], $r[3], $r[4]);
        $stmt->execute();
    }
    $stmt->close();
}

$pageCountResult = $conn->query("SELECT COUNT(*) AS c FROM static_pages");
$pageCount = $pageCountResult ? (int)$pageCountResult->fetch_assoc()['c'] : 0;
if ($pageCount === 0) {
    $pages = [
        ['rooms','Room Information','Choose from Standard, Deluxe, Executive and Suite rooms. Every room includes Wi-Fi, housekeeping and essential guest amenities.'],
        ['about','About Us','StayEase Hotel provides comfortable accommodation with a simple online booking experience. Our goal is to make every stay convenient, transparent and relaxing.'],
        ['contact','Contact Us',"StayEase Hotel\nPhone: +91 98765 43210\nEmail: support@stayease.test\nAddress: 24 Lake View Road, Chennai, India\nCustomer desk: 24/7"],
        ['faq','Customer Service Q&A',"Q: How can I modify my booking?\nA: Log in to your dashboard and use Manage Booking. Changes are allowed at least 3 days before arrival.\n\nQ: Can I cancel?\nA: Yes, cancellation is available at least 3 days before arrival.\n\nQ: How do I check availability?\nA: Enter your dates on the Rooms page and the system checks the room inventory."],
        ['travel','Local Travel & Shipping Guide','Chennai Central and major transport points are accessible from the hotel. Ask the front desk about taxis, airport transfers, local attractions and luggage/shipping assistance.'],
        ['privacy','Privacy Policy','StayEase collects account and booking information required to provide hotel services. Passwords are stored securely. We do not sell guest information.']
    ];
    $stmt = $conn->prepare("INSERT INTO static_pages(page_key,title,content) VALUES(?,?,?)");
    foreach ($pages as $p) {
        $stmt->bind_param('sss', $p[0], $p[1], $p[2]);
        $stmt->execute();
    }
    $stmt->close();
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function nights_between($checkin, $checkout) {
    $a = strtotime($checkin);
    $b = strtotime($checkout);
    return ($a !== false && $b !== false && $b > $a) ? (int)round(($b - $a) / 86400) : 0;
}

function available_rooms($conn, $roomId, $checkin, $checkout) {
    $stmt = $conn->prepare("SELECT r.quantity - COALESCE((SELECT COUNT(*) FROM bookings b WHERE b.room_id=r.id AND b.status='Confirmed' AND b.checkin < ? AND b.checkout > ?),0) AS available FROM rooms r WHERE r.id=?");
    if (!$stmt) return 0;
    $stmt->bind_param('ssi', $checkout, $checkin, $roomId);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return max(0, (int)($result['available'] ?? 0));
}

function valid_booking_dates($checkin, $checkout) {
    $today = strtotime(date('Y-m-d'));
    $in = strtotime($checkin);
    $out = strtotime($checkout);
    return $in !== false && $out !== false && $in >= $today && $out > $in;
}
?>
