<?php
define('BASE_URL', '/onlinehotelroombooking');
define('HOTEL_NAME', 'StayEase Hotel');
date_default_timezone_set('Asia/Kolkata');
?>