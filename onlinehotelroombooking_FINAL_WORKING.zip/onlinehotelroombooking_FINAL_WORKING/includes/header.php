<?php require_once __DIR__ . '/config.php'; ?>
<header class="site-header">
  <a class="logo" href="<?=BASE_URL?>/index.php">Stay<span>Ease</span></a>
  <nav>
    <a href="<?=BASE_URL?>/index.php">Home</a>
    <a href="<?=BASE_URL?>/user/search.php">Rooms</a>
    <a href="<?=BASE_URL?>/user/static.php?page=about">About</a>
    <a href="<?=BASE_URL?>/user/static.php?page=contact">Contact</a>
    <a href="<?=BASE_URL?>/user/dashboard.php">My Bookings</a>
    <a class="nav-pill" href="<?=BASE_URL?>/user/login.php">Login</a>
  </nav>
</header>