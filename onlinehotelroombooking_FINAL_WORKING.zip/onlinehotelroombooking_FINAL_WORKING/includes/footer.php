<footer>
  <div><div class="footer-logo">StayEase Hotel</div><p>Comfortable stays. Simple booking.</p></div>
  <div class="footer-links">
    <a href="<?=BASE_URL?>/user/static.php?page=privacy">Privacy</a>
    <a href="<?=BASE_URL?>/user/static.php?page=faq">Customer Q&A</a>
    <a href="<?=BASE_URL?>/user/static.php?page=travel">Travel Guide</a>
    <a href="<?=BASE_URL?>/user/static.php?page=contact">Contact</a>
  </div>
</footer>