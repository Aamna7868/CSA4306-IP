<?php
session_start(); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $username=$_POST['username']??''; $password=$_POST['password']??'';
    if(hash_equals('admin',$username) && hash_equals('admin123',$password)){
        session_regenerate_id(true); $_SESSION['admin']=true; header('Location: dashboard.php'); exit;
    }
    $error='Invalid admin credentials.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="../assets/style.css"></head><body><div class="formbox"><span class="eyebrow">STAYEASE ADMIN</span><h1>Control Center</h1><?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif;?><form method="post"><label>Username</label><input name="username" autocomplete="username" required><label>Password</label><input name="password" type="password" autocomplete="current-password" required><button class="btn">Sign In</button></form><p>Demo login: <b>admin</b> / <b>admin123</b></p></div></body></html>
