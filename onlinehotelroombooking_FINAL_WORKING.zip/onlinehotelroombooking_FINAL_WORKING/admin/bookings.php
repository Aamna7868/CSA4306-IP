<?php
require_once '../includes/db.php'; session_start();
if(empty($_SESSION['admin'])){header('Location: login.php');exit;}
$msg='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $id=(int)($_POST['id']??0);
    if(isset($_POST['cancel'])){
        $st=$conn->prepare("UPDATE bookings SET status='Cancelled',payment_status='Refunded' WHERE id=?");$st->bind_param('i',$id);$st->execute();$st->close();$msg='Booking cancelled.';
    }elseif(isset($_POST['save'])){
        $in=trim($_POST['checkin']??'');$out=trim($_POST['checkout']??'');$status=$_POST['status']??'Confirmed';
        if(!in_array($status,['Confirmed','Cancelled'],true)) $error='Invalid booking status.';
        elseif(!valid_booking_dates($in,$out)) $error='Invalid booking dates.';
        else{
            $st=$conn->prepare('SELECT room_id,guests FROM bookings WHERE id=?');$st->bind_param('i',$id);$st->execute();$old=$st->get_result()->fetch_assoc();$st->close();
            if(!$old) $error='Booking not found.';
            elseif($status==='Confirmed'){
                $conn->begin_transaction();
                try{
                    $lock=$conn->prepare('SELECT quantity,price,capacity FROM rooms WHERE id=? FOR UPDATE');$lock->bind_param('i',$old['room_id']);$lock->execute();$room=$lock->get_result()->fetch_assoc();$lock->close();
                    if(!$room) throw new Exception('Room not found.');
                    if((int)$old['guests']>(int)$room['capacity']) throw new Exception('Existing guest count exceeds room capacity.');
                    $available=available_rooms($conn,$old['room_id'],$in,$out);
                    if($available<1) throw new Exception('No availability for the selected dates.');
                    $total=nights_between($in,$out)*(float)$room['price'];
                    $st=$conn->prepare("UPDATE bookings SET checkin=?,checkout=?,status='Confirmed',payment_status='Paid',total=? WHERE id=?");$st->bind_param('ssdi',$in,$out,$total,$id);$st->execute();$st->close();$conn->commit();$msg='Booking updated.';
                }catch(Throwable $ex){$conn->rollback();$error=$ex->getMessage();}
            }else{
                $st=$conn->prepare("UPDATE bookings SET checkin=?,checkout=?,status='Cancelled',payment_status='Refunded' WHERE id=?");$st->bind_param('ssi',$in,$out,$id);$st->execute();$st->close();$msg='Booking cancelled.';
            }
        }
    }
}
$bs=$conn->query('SELECT b.*,u.name,u.email,r.room_type FROM bookings b JOIN users u ON b.user_id=u.id JOIN rooms r ON b.room_id=r.id ORDER BY b.id DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Bookings</title><link rel="stylesheet" href="../assets/style.css"></head><body><?php include 'nav.php';?><section class="section"><h1>Manage Bookings</h1><?php if($msg):?><div class="notice"><?=e($msg)?></div><?php endif;?><?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif;?><div class="tablewrap"><table><tr><th>Guest</th><th>Room</th><th>Dates</th><th>Guests</th><th>Total</th><th>Payment</th><th>Status</th><th>Action</th></tr><?php while($b=$bs->fetch_assoc()):?><tr><form method="post"><td><?=e($b['name'])?><br><small><?=e($b['email'])?></small></td><td><?=e($b['room_type'])?></td><td><input type="date" name="checkin" value="<?=e($b['checkin'])?>"><input type="date" name="checkout" value="<?=e($b['checkout'])?>"></td><td><?=$b['guests']?></td><td>₹<?=number_format($b['total'],2)?></td><td><?=e($b['payment_status'])?></td><td><select name="status"><option value="Confirmed" <?=$b['status']==='Confirmed'?'selected':''?>>Confirmed</option><option value="Cancelled" <?=$b['status']==='Cancelled'?'selected':''?>>Cancelled</option></select></td><td><input type="hidden" name="id" value="<?=$b['id']?>"><button name="save">Save</button> <button name="cancel" onclick="return confirm('Cancel this booking?')">Cancel</button></td></form></tr><?php endwhile;?></table></div></section></body></html>
