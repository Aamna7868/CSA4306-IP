<?php require_once '../includes/db.php';
$checkin=$_GET['checkin']??''; $checkout=$_GET['checkout']??''; $guests=(int)($_GET['guests']??2);
$valid=$checkin && $checkout && strtotime($checkout)>strtotime($checkin) && strtotime($checkin)>=strtotime(date('Y-m-d'));
$rooms=$conn->query("SELECT * FROM rooms ORDER BY price");
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rooms | StayEase</title><link rel="stylesheet" href="../assets/style.css"></head><body><?php include '../includes/header.php'; ?>
<section class="section"><span class="eyebrow">ROOM SEARCH</span><h1>Check availability</h1>
<form class="searchbar" method="get"><input type="date" name="checkin" value="<?=e($checkin)?>" min="<?=date('Y-m-d')?>" required><input type="date" name="checkout" value="<?=e($checkout)?>" min="<?=date('Y-m-d',strtotime('+1 day'))?>" required><input type="number" name="guests" value="<?=$guests?>" min="1" max="10" required><button class="btn">Search</button></form>
<?php if($checkin && !$valid): ?><div class="notice error">Please select a valid future check-in date and a checkout date after check-in.</div><?php endif; ?>
<div class="cards"><?php while($r=$rooms->fetch_assoc()): $available=$valid?available_rooms($conn,$r['id'],$checkin,$checkout):$r['quantity']; $fits=$guests<=$r['capacity']; ?>
<article class="card"><div class="room-img"></div><h2><?=e($r['room_type'])?></h2><p><?=e($r['description'])?></p><p>Capacity: <?=$r['capacity']?> · <b><?= $valid ? $available : $r['quantity'] ?></b> available</p><strong>₹<?=number_format($r['price'])?> / night</strong><br><?php if($valid && $available>0 && $fits): ?><a class="btn small" href="book.php?room=<?=$r['id']?>&checkin=<?=e($checkin)?>&checkout=<?=e($checkout)?>&guests=<?=$guests?>">Book Now</a><?php elseif(!$valid): ?><span class="notice">Enter dates to book</span><?php elseif(!$fits): ?><span class="notice error">Too many guests</span><?php else: ?><span class="notice error">Sold out for these dates</span><?php endif; ?></article>
<?php endwhile; ?></div></section><?php include '../includes/footer.php'; ?></body></html>