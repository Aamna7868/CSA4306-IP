<?php
require_once '../includes/db.php'; session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$uid=$_SESSION['user_id']; $id=(int)($_GET['id']??0); $msg=''; $error='';
$st=$conn->prepare('SELECT b.*,r.room_type,r.price,r.capacity FROM bookings b JOIN rooms r ON b.room_id=r.id WHERE b.id=? AND b.user_id=?');
$st->bind_param('ii',$id,$uid); $st->execute(); $b=$st->get_result()->fetch_assoc(); $st->close();
if(!$b) die('Booking not found.');

$daysUntil=(int)floor((strtotime($b['checkin'])-strtotime(date('Y-m-d')))/86400);
if($_SERVER['REQUEST_METHOD']==='POST') {
    if($b['status']!=='Confirmed') $error='This booking is already cancelled.';
    elseif($daysUntil<3) $error='Changes and cancellations are allowed only at least 3 days before arrival.';
    elseif(isset($_POST['cancel'])) {
        $st=$conn->prepare("UPDATE bookings SET status='Cancelled',payment_status='Refunded' WHERE id=? AND user_id=? AND status='Confirmed'");
        $st->bind_param('ii',$id,$uid); $st->execute(); $st->close(); $msg='Booking cancelled and marked for refund.'; $b['status']='Cancelled'; $b['payment_status']='Refunded';
    } elseif(isset($_POST['change'])) {
        $in=trim($_POST['checkin']??''); $out=trim($_POST['checkout']??''); $g=(int)($_POST['guests']??0);
        if(!valid_booking_dates($in,$out)) $error='Invalid future dates.';
        elseif($g<1||$g>(int)$b['capacity']) $error='Guest count exceeds capacity.';
        else {
            $conn->begin_transaction();
            try {
                $lock=$conn->prepare('SELECT quantity,price,capacity FROM rooms WHERE id=? FOR UPDATE'); $lock->bind_param('i',$b['room_id']); $lock->execute(); $rr=$lock->get_result()->fetch_assoc(); $lock->close();
                if(!$rr) throw new Exception('Room not found.');
                if($g>(int)$rr['capacity']) throw new Exception('Guest count exceeds capacity.');
                $available=available_rooms($conn,$b['room_id'],$in,$out);
                /* The current booking is included in availability, so add one back for its existing slot. */
                if($in===$b['checkin'] && $out===$b['checkout']) $available++;
                if($available<1) throw new Exception('No availability for the new dates.');
                $total=nights_between($in,$out)*(float)$rr['price'];
                $st=$conn->prepare('UPDATE bookings SET checkin=?,checkout=?,guests=?,total=? WHERE id=? AND user_id=? AND status=\'Confirmed\'');
                $st->bind_param('ssidii',$in,$out,$g,$total,$id,$uid);
                if(!$st->execute()) throw new Exception('Booking could not be updated.');
                $st->close(); $conn->commit();
                $msg='Booking updated successfully.'; $b['checkin']=$in; $b['checkout']=$out; $b['guests']=$g; $b['total']=$total;
            } catch(Throwable $ex) { $conn->rollback(); $error=$ex->getMessage(); }
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Manage Booking</title><link rel="stylesheet" href="../assets/style.css"></head><body><?php include '../includes/header.php';?><div class="formbox"><span class="eyebrow">MANAGE BOOKING</span><h1><?=e($b['room_type'])?></h1><?php if($msg):?><div class="notice"><?=e($msg)?></div><?php endif;?><?php if($error):?><div class="notice error"><?=e($error)?></div><?php endif;?><p>Current status: <b><?=e($b['status'])?></b></p><?php if($b['status']==='Confirmed'):?><form method="post"><label>Check-in</label><input type="date" name="checkin" value="<?=e($b['checkin'])?>" min="<?=date('Y-m-d')?>" required><label>Check-out</label><input type="date" name="checkout" value="<?=e($b['checkout'])?>" min="<?=date('Y-m-d',strtotime('+1 day'))?>" required><label>Guests</label><input type="number" name="guests" value="<?=$b['guests']?>" min="1" max="<?=$b['capacity']?>" required><button class="btn" name="change">Save Changes</button> <button class="btn danger" name="cancel" onclick="return confirm('Cancel this booking?')">Cancel Booking</button></form><p>Policy: changes/cancellations are available at least 3 days before arrival.</p><?php endif;?></div></body></html>
