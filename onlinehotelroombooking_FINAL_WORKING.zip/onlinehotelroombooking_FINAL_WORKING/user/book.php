<?php
require_once '../includes/db.php';
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

$roomId = (int)($_GET['room'] ?? $_POST['room_id'] ?? 0);
$st = $conn->prepare('SELECT * FROM rooms WHERE id=?');
$st->bind_param('i', $roomId); $st->execute(); $room = $st->get_result()->fetch_assoc(); $st->close();
if (!$room) die('Room not found.');

$checkin = $_GET['checkin'] ?? '';
$checkout = $_GET['checkout'] ?? '';
$guests = (int)($_GET['guests'] ?? 2);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $checkin = trim($_POST['checkin'] ?? '');
    $checkout = trim($_POST['checkout'] ?? '');
    $guests = (int)($_POST['guests'] ?? 0);
    $payment = $_POST['payment'] ?? 'card';

    if (!valid_booking_dates($checkin, $checkout)) {
        $error = 'Please choose valid future dates. Check-out must be after check-in.';
    } elseif ($guests < 1 || $guests > (int)$room['capacity']) {
        $error = 'Guest count exceeds this room capacity.';
    } elseif (!in_array($payment, ['card','upi','netbanking'], true)) {
        $error = 'Please select a valid payment method.';
    } else {
        /* Lock the room row while checking and creating the booking to prevent double booking. */
        $conn->begin_transaction();
        try {
            $lock = $conn->prepare('SELECT quantity, price, capacity FROM rooms WHERE id=? FOR UPDATE');
            $lock->bind_param('i', $roomId); $lock->execute(); $lockedRoom = $lock->get_result()->fetch_assoc(); $lock->close();
            if (!$lockedRoom) throw new Exception('Room not found.');
            if ($guests > (int)$lockedRoom['capacity']) throw new Exception('Guest count exceeds this room capacity.');

            $available = available_rooms($conn, $roomId, $checkin, $checkout);
            if ($available < 1) throw new Exception('This room type is no longer available for the selected dates.');

            $nights = nights_between($checkin, $checkout);
            $total = $nights * (float)$lockedRoom['price'];
            $ref = 'SE' . date('YmdHis') . random_int(100, 999);
            $status = 'Confirmed'; $paid = 'Paid';
            $st = $conn->prepare('INSERT INTO bookings(user_id,room_id,checkin,checkout,guests,total,status,payment_status,payment_ref) VALUES(?,?,?,?,?,?,?,?,?)');
            $st->bind_param('iissidsss', $_SESSION['user_id'], $roomId, $checkin, $checkout, $guests, $total, $status, $paid, $ref);
            if (!$st->execute()) throw new Exception('Booking could not be saved: ' . $st->error);
            $bookingId = $conn->insert_id; $st->close();
            $conn->commit();
            header("Location: confirmation.php?id=$bookingId"); exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            $error = $ex->getMessage();
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Book <?=e($room['room_type'])?></title><link rel="stylesheet" href="../assets/style.css"></head><body>
<?php include '../includes/header.php'; ?>
<div class="formbox"><span class="eyebrow">SECURE CHECKOUT</span><h1><?=e($room['room_type'])?></h1><p><?=e($room['description'])?></p>
<?php if($error): ?><div class="notice error"><?=e($error)?></div><?php endif; ?>
<form method="post">
<input type="hidden" name="room_id" value="<?=$roomId?>">
<label>Check-in</label><input type="date" name="checkin" value="<?=e($checkin)?>" min="<?=date('Y-m-d')?>" required>
<label>Check-out</label><input type="date" name="checkout" value="<?=e($checkout)?>" min="<?=date('Y-m-d',strtotime('+1 day'))?>" required>
<label>Guests</label><input type="number" name="guests" value="<?=max(1,$guests)?>" min="1" max="<?=$room['capacity']?>" required>
<label>Payment method</label><select name="payment"><option value="card">Card / Demo Gateway</option><option value="upi">UPI / Demo Gateway</option><option value="netbanking">Net Banking / Demo Gateway</option></select>
<div class="notice">Demo payment: no real money is charged. A payment reference is generated after confirmation.</div>
<button class="btn">Pay & Confirm Booking</button></form></div></body></html>
