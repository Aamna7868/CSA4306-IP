STAYEASE HOTEL ROOM BOOKING SYSTEM - FINAL WORKING XAMPP VERSION

INSTALLATION
1. Extract the folder to: C:\xampp\htdocs\onlinehotelroombooking
2. Start Apache and MySQL in XAMPP. Both services must be green/running.
3. Open: http://localhost/onlinehotelroombooking/
4. The PHP app automatically creates/updates the hoteleasy database and required tables.
5. If you previously used an older version, this version includes schema-upgrade checks so old tables do not have to be manually deleted.
6. If MySQL root has a password, open includes/db.php and change $dbPass from '' to your MySQL root password.

ADMIN
URL: http://localhost/onlinehotelroombooking/admin/login.php
Username: admin
Password: admin123

USER
Register at: http://localhost/onlinehotelroombooking/user/register.php

MAIN FEATURES
- User registration/login/logout and profile
- Search rooms by check-in/check-out and guest count
- Date-based room inventory calculation
- Four room types
- Booking with demo payment reference
- Booking confirmation page
- Booking history
- Modify/cancel only at least 3 days before arrival
- Admin room quantity/price management
- Admin booking edit/cancel
- Six editable static pages
- Reviews and ratings
- Responsive design
- Automatic database creation and seed data
- Booking transaction locking to reduce double-booking race conditions
- Validation and clearer database error messages

IMPORTANT
The payment gateway is simulated for an academic/demo project. It does not charge real money.
Email confirmation is represented by the on-screen confirmation reference; SMTP must be connected for real email delivery.
