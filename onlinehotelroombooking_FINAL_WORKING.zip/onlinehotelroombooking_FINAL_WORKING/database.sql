CREATE DATABASE IF NOT EXISTS hoteleasy CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hoteleasy;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 phone VARCHAR(30) DEFAULT '',
 password VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rooms (
 id INT AUTO_INCREMENT PRIMARY KEY,
 room_type VARCHAR(100) NOT NULL,
 description TEXT NOT NULL,
 capacity INT NOT NULL DEFAULT 2,
 quantity INT NOT NULL DEFAULT 1,
 price DECIMAL(10,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bookings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 room_id INT NOT NULL,
 checkin DATE NOT NULL,
 checkout DATE NOT NULL,
 guests INT NOT NULL,
 total DECIMAL(10,2) NOT NULL,
 status ENUM('Confirmed','Cancelled') NOT NULL DEFAULT 'Confirmed',
 payment_status ENUM('Paid','Pending','Refunded') NOT NULL DEFAULT 'Pending',
 payment_ref VARCHAR(80) DEFAULT '',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX(room_id), INDEX(user_id),
 CONSTRAINT fk_booking_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_booking_room FOREIGN KEY(room_id) REFERENCES rooms(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reviews (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 room_id INT NOT NULL,
 rating INT NOT NULL,
 review TEXT NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_review_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_review_room FOREIGN KEY(room_id) REFERENCES rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS static_pages (
 id INT AUTO_INCREMENT PRIMARY KEY,
 page_key VARCHAR(50) NOT NULL UNIQUE,
 title VARCHAR(150) NOT NULL,
 content TEXT NOT NULL
) ENGINE=InnoDB;

INSERT INTO rooms(room_type,description,capacity,quantity,price)
SELECT * FROM (
 SELECT 'Standard Room','Comfortable room for solo travellers and couples. Includes Wi-Fi, breakfast and housekeeping.',2,10,2500.00
 UNION ALL SELECT 'Deluxe Room','Spacious room with upgraded interiors, breakfast, Wi-Fi and city views.',3,8,3500.00
 UNION ALL SELECT 'Executive Room','Premium business-friendly room with work desk, lounge access and breakfast.',3,6,4800.00
 UNION ALL SELECT 'Suite Room','Large suite with separate living space, premium amenities and complimentary breakfast.',4,4,7000.00
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM rooms);
