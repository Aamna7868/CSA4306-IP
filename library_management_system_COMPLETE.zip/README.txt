LIBRANEST - LIBRARY MANAGEMENT SYSTEM
=====================================

DESIGN
------
Complete UI refresh for the student and administrator areas.
Responsive navy/teal/gold library theme, updated cards, forms, tables,
admin dashboard, catalog, login and registration screens.

XAMPP SETUP
-----------
1. Extract this folder into C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/library_management_system_redesigned/
4. The database library_db and required tables are created automatically.

ADMIN LOGIN
-----------
Username: admin
Password: admin123
Admin URL: /admin/login.php

DEMO STUDENT LOGIN
------------------
Email: student@library.test
Password: student123

The demo student is created automatically on the first database connection.
Students can also register their own accounts.

SAMPLE BOOKS
------------
The Alchemist — Paulo Coelho
Wings of Fire — A. P. J. Abdul Kalam
Atomic Habits — James Clear
The Psychology of Money — Morgan Housel
Clean Code — Robert C. Martin
Computer Networks — Andrew S. Tanenbaum
Artificial Intelligence: A Modern Approach — Stuart Russell & Peter Norvig
Database System Concepts — Abraham Silberschatz, Henry Korth & S. Sudarshan
Pride and Prejudice — Jane Austen
1984 — George Orwell
Introduction to Algorithms — Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest & Clifford Stein
The Guide — R. K. Narayan

IMPORTANT
---------
These are demo credentials for local development/presentation. Change the
administrator password before using the system in a real deployment.
