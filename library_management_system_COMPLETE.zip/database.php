<?php
session_start();
$host="localhost"; $user="root"; $pass=""; $db="library_db";
$conn=new mysqli($host,$user,$pass);
if($conn->connect_error) die("Database connection failed: ".$conn->connect_error);
$conn->query("CREATE DATABASE IF NOT EXISTS `$db`");
$conn->select_db($db); $conn->set_charset("utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY,username VARCHAR(50) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)");
$conn->query("CREATE TABLE IF NOT EXISTS books(id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,author VARCHAR(150) NOT NULL,isbn VARCHAR(50),category VARCHAR(100),quantity INT NOT NULL DEFAULT 1,available INT NOT NULL DEFAULT 1,description TEXT)");
$conn->query("CREATE TABLE IF NOT EXISTS issues(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,book_id INT NOT NULL,issue_date DATE NOT NULL,due_date DATE NOT NULL,return_date DATE NULL,status ENUM('Pending','Issued','Returned','Rejected') DEFAULT 'Pending',FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE)");
$conn->query("CREATE TABLE IF NOT EXISTS messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150),message TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$check=$conn->query("SELECT id FROM admins LIMIT 1");
if($check && $check->num_rows===0){$hash=password_hash("admin123",PASSWORD_DEFAULT);$stmt=$conn->prepare("INSERT INTO admins(username,password) VALUES('admin',?)");$stmt->bind_param("s",$hash);$stmt->execute();}
// Demo student account for presentation/testing.
$check=$conn->query("SELECT id FROM users WHERE email='student@library.test' LIMIT 1");
if($check && $check->num_rows===0){$hash=password_hash("student123",PASSWORD_DEFAULT);$stmt=$conn->prepare("INSERT INTO users(name,email,password) VALUES('Aamna Khan','student@library.test',?)");$stmt->bind_param("s",$hash);$stmt->execute();}
// Seed a useful catalog on first run.
$count=$conn->query("SELECT COUNT(*) n FROM books")->fetch_assoc()['n'];
if((int)$count===0){
 $seed=[
 ['The Alchemist','Paulo Coelho','9780062315007','Fiction',5,'A timeless story about following dreams, purpose and personal discovery.'],
 ['Wings of Fire','A. P. J. Abdul Kalam','9788173711466','Biography',4,'The inspiring autobiography of Dr. A. P. J. Abdul Kalam.'],
 ['Atomic Habits','James Clear','9780735211292','Self Development',6,'A practical guide to building good habits and breaking bad ones.'],
 ['The Psychology of Money','Morgan Housel','9780857197689','Finance',4,'Timeless lessons on wealth, behavior and financial decision making.'],
 ['Clean Code','Robert C. Martin','9780132350884','Programming',3,'A practical guide to writing readable, maintainable software.'],
 ['Computer Networks','Andrew S. Tanenbaum','9780132126953','Computer Science',3,'Core networking concepts, protocols, architectures and applications.'],
 ['Artificial Intelligence: A Modern Approach','Stuart Russell & Peter Norvig','9780134610993','Artificial Intelligence',4,'A comprehensive introduction to modern artificial intelligence.'],
 ['Database System Concepts','Abraham Silberschatz, Henry Korth & S. Sudarshan','9780078022159','Database',3,'Fundamental database concepts, design, transactions and systems.'],
 ['Pride and Prejudice','Jane Austen','9780141439518','Classic',4,'A classic novel of manners, relationships and social expectations.'],
 ['1984','George Orwell','9780451524935','Classic',4,'A landmark dystopian novel about surveillance, power and truth.'],
 ['Introduction to Algorithms','Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest & Clifford Stein','9780262046305','Algorithms',2,'A comprehensive reference for algorithms and data structures.'],
 ['The Guide','R. K. Narayan','9788185986172','Indian Literature',3,'A celebrated Indian novel exploring transformation, identity and human relationships.']
 ];
 $stmt=$conn->prepare("INSERT INTO books(title,author,isbn,category,quantity,available,description) VALUES(?,?,?,?,?,?,?)");
 foreach($seed as $b){$stmt->bind_param("ssssiis",$b[0],$b[1],$b[2],$b[3],$b[4],$b[4],$b[5]);$stmt->execute();}
}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function require_login(){if(empty($_SESSION['user_id'])){header("Location: login.php");exit;}}
function require_admin(){if(empty($_SESSION['admin_id'])){header("Location: login.php");exit;}}
?>
